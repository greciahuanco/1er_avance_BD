import java.sql.*;
import java.util.Scanner;

public class conexionBDoracle {

    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USER = "Tecsup";
    private static final String PASSWORD = "Tecsup";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Conectado a la base de datos");

            int opcion;
            do {
                System.out.println("\n=== MENU PRINCIPAL ===");
                System.out.println("1. Insertar Estudiante");
                System.out.println("2. Actualizar Estudiante");
                System.out.println("3. Eliminar Estudiante");
                System.out.println("4. Ver Estudiantes");
                System.out.println("5. Ver Cursos");
                System.out.println("6. Consultas Avanzadas");
                System.out.println("7. PROCEDIMIENTOS ALMACENADOS");
                System.out.println("8. VISTAS AVANZADAS");
                System.out.println("9. AUDITORÍA");
                System.out.println("0. Salir");
                System.out.print("Opcion: ");

                opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1 -> insertarEstudiante(conn, scanner);
                    case 2 -> actualizarEstudiante(conn, scanner);
                    case 3 -> eliminarEstudiante(conn, scanner);
                    case 4 -> verEstudiantes(conn);
                    case 5 -> verCursos(conn);
                    case 6 -> consultasAvanzadas(conn);
                    case 7 -> menuProcedimientosAlmacenados(conn, scanner);
                    case 8 -> menuVistas(conn);
                    case 9 -> mostrarAuditoria(conn);
                    case 0 -> System.out.println("Saliendo...");
                    default -> System.out.println("Opcion no valida");
                }

            } while (opcion != 0);

        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    // INSERTAR ESTUDIANTE
    public static void insertarEstudiante(Connection conn, Scanner scanner) {
        try {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Apellido: ");
            String apellido = scanner.nextLine();
            System.out.print("DNI (8 dígitos): ");
            String dni = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();

            // Validar DNI antes de insertar
            if (dni.length() != 8 || !dni.matches("\\d+")) {
                System.out.println("ERROR: El DNI debe tener exactamente 8 dígitos numéricos");
                return;
            }

            String sql = "INSERT INTO Estudiante VALUES (seq_estudiante.NEXTVAL, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            pstmt.setString(3, dni);
            pstmt.setString(4, email);

            pstmt.executeUpdate();
            System.out.println("Estudiante agregado correctamente");

        } catch (SQLException e) {
            System.out.println("Error al insertar: " + e.getMessage());
        }
    }

    // ACTUALIZAR ESTUDIANTE
    public static void actualizarEstudiante(Connection conn, Scanner scanner) {
        try {
            verEstudiantes(conn);
            System.out.print("ID del estudiante a actualizar: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Nuevo nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Nuevo email: ");
            String email = scanner.nextLine();

            String sql = "UPDATE Estudiante SET nombre = ?, email = ? WHERE id_estudiante = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombre);
            pstmt.setString(2, email);
            pstmt.setInt(3, id);

            int filas = pstmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Estudiante actualizado");
            } else {
                System.out.println("No se encontro el ID");
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ELIMINAR ESTUDIANTE
    public static void eliminarEstudiante(Connection conn, Scanner scanner) {
        try {
            verEstudiantes(conn);
            System.out.print("ID del estudiante a eliminar: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            // Primero eliminar matriculas
            String sql1 = "DELETE FROM Matricula WHERE id_estudiante = ?";
            PreparedStatement pstmt1 = conn.prepareStatement(sql1);
            pstmt1.setInt(1, id);
            pstmt1.executeUpdate();

            String sql2 = "DELETE FROM Estudiante WHERE id_estudiante = ?";
            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            pstmt2.setInt(1, id);

            int filas = pstmt2.executeUpdate();
            if (filas > 0) {
                System.out.println("Estudiante eliminado");
            } else {
                System.out.println("No se encontro el ID");
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // VER ESTUDIANTES
    public static void verEstudiantes(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Estudiante");

            System.out.println("\n--- ESTUDIANTES ---");
            while (rs.next()) {
                System.out.println(rs.getInt("id_estudiante") + " | " +
                        rs.getString("nombre") + " | " +
                        rs.getString("apellido") + " | " +
                        rs.getString("email"));
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // VER CURSOS
    public static void verCursos(Connection conn) {
        try {
            String sql = "SELECT c.id_curso, c.nombre, c.duracion_semanas, d.nombre as docente " +
                    "FROM Curso c JOIN Docente d ON c.id_docente = d.id_docente";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("\n--- CURSOS ---");
            while (rs.next()) {
                System.out.println(rs.getInt("id_curso") + " | " +
                        rs.getString("nombre") + " | " +
                        rs.getInt("duracion_semanas") + " semanas | " +
                        rs.getString("docente"));
            }

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // CONSULTAS AVANZADAS
    public static void consultasAvanzadas(Connection conn) {
        try {
            System.out.println("\n--- CONSULTA 1: Estudiantes con cantidad de cursos ---");
            String sql1 = "SELECT e.nombre, e.apellido, COUNT(m.id_matricula) as cursos " +
                    "FROM Estudiante e LEFT JOIN Matricula m ON e.id_estudiante = m.id_estudiante " +
                    "GROUP BY e.id_estudiante, e.nombre, e.apellido";
            ejecutarConsulta(conn, sql1);

            System.out.println("\n--- CONSULTA 2: Todos los datos de matriculas ---");
            String sql2 = "SELECT e.nombre, e.apellido, c.nombre as curso, d.nombre as docente, m.fecha " +
                    "FROM Matricula m " +
                    "JOIN Estudiante e ON m.id_estudiante = e.id_estudiante " +
                    "JOIN Curso c ON m.id_curso = c.id_curso " +
                    "JOIN Docente d ON c.id_docente = d.id_docente";
            ejecutarConsulta(conn, sql2);

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // MÉTODO AUXILIAR PARA EJECUTAR CONSULTAS
    public static void ejecutarConsulta(Connection conn, String sql) throws SQLException {
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();

        // Mostrar columnas
        for (int i = 1; i <= columnCount; i++) {
            System.out.print(meta.getColumnName(i) + " | ");
        }
        System.out.println();

        while (rs.next()) {
            for (int i = 1; i <= columnCount; i++) {
                System.out.print(rs.getString(i) + " | ");
            }
            System.out.println();
        }

        rs.close();
        stmt.close();
    }

    // ==========================================
    // ENTREGA 3 - NUEVOS MÉTODOS
    // ==========================================

    // MENÚ PARA PROCEDIMIENTOS ALMACENADOS
    public static void menuProcedimientosAlmacenados(Connection conn, Scanner scanner) {
        int opcion;
        do {
            System.out.println("\n=== PROCEDIMIENTOS ALMACENADOS ===");
            System.out.println("1. Estudiantes por Curso");
            System.out.println("2. Contar Estudiantes en Curso");
            System.out.println("3. Matricular Estudiante");
            System.out.println("0. Volver");
            System.out.print("Opcion: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> llamarProcedimientoEstudiantesCurso(conn, scanner);
                case 2 -> llamarProcedimientoContarEstudiantes(conn, scanner);
                case 3 -> llamarProcedimientoMatricularEstudiante(conn, scanner);
                case 0 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opcion no valida");
            }

        } while (opcion != 0);
    }

    // PROCEDIMIENTO: ESTUDIANTES POR CURSO
    public static void llamarProcedimientoEstudiantesCurso(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del curso: ");
            int idCurso = scanner.nextInt();

            // Versión simplificada usando consulta directa
            String sql = "SELECT e.id_estudiante, e.nombre, e.apellido, e.email, e.dni " +
                    "FROM Estudiante e " +
                    "JOIN Matricula m ON e.id_estudiante = m.id_estudiante " +
                    "WHERE m.id_curso = ?";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idCurso);
            ResultSet rs = stmt.executeQuery();

            System.out.println("\n--- ESTUDIANTES EN EL CURSO " + idCurso + " ---");
            boolean hayResultados = false;
            while (rs.next()) {
                hayResultados = true;
                System.out.println("ID: " + rs.getInt("id_estudiante") +
                        " | Nombre: " + rs.getString("nombre") +
                        " " + rs.getString("apellido") +
                        " | Email: " + rs.getString("email") +
                        " | DNI: " + rs.getString("dni"));
            }

            if (!hayResultados) {
                System.out.println("No hay estudiantes matriculados en este curso.");
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // PROCEDIMIENTO: CONTAR ESTUDIANTES EN CURSO
    public static void llamarProcedimientoContarEstudiantes(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del curso: ");
            int idCurso = scanner.nextInt();

            // Versión simplificada usando consulta directa
            String sql = "SELECT COUNT(*) as total FROM Matricula WHERE id_curso = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idCurso);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int total = rs.getInt("total");
                System.out.println("Total de estudiantes en el curso " + idCurso + ": " + total);
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // PROCEDIMIENTO: MATRICULAR ESTUDIANTE
    public static void llamarProcedimientoMatricularEstudiante(Connection conn, Scanner scanner) {
        try {
            System.out.print("ID del estudiante: ");
            int idEstudiante = scanner.nextInt();
            System.out.print("ID del curso: ");
            int idCurso = scanner.nextInt();

            // Verificar si existe el estudiante
            String sqlCheckEst = "SELECT COUNT(*) FROM Estudiante WHERE id_estudiante = ?";
            PreparedStatement stmtCheckEst = conn.prepareStatement(sqlCheckEst);
            stmtCheckEst.setInt(1, idEstudiante);
            ResultSet rsEst = stmtCheckEst.executeQuery();
            rsEst.next();
            int existeEst = rsEst.getInt(1);
            rsEst.close();
            stmtCheckEst.close();

            if (existeEst == 0) {
                System.out.println("ERROR: El estudiante no existe");
                return;
            }

            // Verificar si existe el curso
            String sqlCheckCur = "SELECT COUNT(*) FROM Curso WHERE id_curso = ?";
            PreparedStatement stmtCheckCur = conn.prepareStatement(sqlCheckCur);
            stmtCheckCur.setInt(1, idCurso);
            ResultSet rsCur = stmtCheckCur.executeQuery();
            rsCur.next();
            int existeCur = rsCur.getInt(1);
            rsCur.close();
            stmtCheckCur.close();

            if (existeCur == 0) {
                System.out.println("ERROR: El curso no existe");
                return;
            }

            // Verificar si ya está matriculado
            String sqlCheckMat = "SELECT COUNT(*) FROM Matricula WHERE id_estudiante = ? AND id_curso = ?";
            PreparedStatement stmtCheckMat = conn.prepareStatement(sqlCheckMat);
            stmtCheckMat.setInt(1, idEstudiante);
            stmtCheckMat.setInt(2, idCurso);
            ResultSet rsMat = stmtCheckMat.executeQuery();
            rsMat.next();
            int yaMatriculado = rsMat.getInt(1);
            rsMat.close();
            stmtCheckMat.close();

            if (yaMatriculado > 0) {
                System.out.println("ERROR: El estudiante ya está matriculado en este curso");
                return;
            }

            // Realizar matrícula
            String sqlInsert = "INSERT INTO Matricula (id_matricula, id_estudiante, id_curso, fecha) " +
                    "VALUES (seq_matricula.NEXTVAL, ?, ?, SYSDATE)";
            PreparedStatement stmtInsert = conn.prepareStatement(sqlInsert);
            stmtInsert.setInt(1, idEstudiante);
            stmtInsert.setInt(2, idCurso);
            stmtInsert.executeUpdate();
            stmtInsert.close();

            System.out.println("ÉXITO: Estudiante matriculado correctamente");

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // MENÚ PARA VISTAS AVANZADAS
    public static void menuVistas(Connection conn) {
        try {
            System.out.println("\n=== VISTAS AVANZADAS ===");

            System.out.println("\n--- RESUMEN DE ESTUDIANTES ---");
            String sql1 = "SELECT * FROM vista_resumen_estudiantes";
            ejecutarConsulta(conn, sql1);

            System.out.println("\n--- CURSOS CON DOCENTES ---");
            String sql2 = "SELECT * FROM vista_cursos_docentes";
            ejecutarConsulta(conn, sql2);

            System.out.println("\n--- ESTADÍSTICAS DEL SISTEMA ---");
            String sql3 = "SELECT * FROM vista_estadisticas_sistema";
            ejecutarConsulta(conn, sql3);

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // MOSTRAR AUDITORÍA
    public static void mostrarAuditoria(Connection conn) {
        try {
            String sql = "SELECT * FROM Auditoria_Estudiante ORDER BY fecha DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("\n=== AUDITORÍA DE ESTUDIANTES ===");
            boolean hayRegistros = false;
            while (rs.next()) {
                hayRegistros = true;
                System.out.println("ID: " + rs.getInt("id_auditoria") +
                        " | Estudiante: " + rs.getInt("id_estudiante") +
                        " | Acción: " + rs.getString("accion") +
                        " | Fecha: " + rs.getTimestamp("fecha") +
                        " | Usuario: " + rs.getString("usuario") +
                        " | Datos: " + rs.getString("datos_anteriores"));
            }

            if (!hayRegistros) {
                System.out.println("No hay registros de auditoría aún.");
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}